# 🧬 Site-12 — Intranet Fondation SCP

Bienvenue sur l'intranet du **Site-12**, dernier bastion de la Fondation SCP.

🛰️ Interface immersive, conçue pour une expérience RP complète :
- Accès sécurisé par terminal RP
- État du site en temps réel
- Générateur de rapports et journal interne
- Interface admin (O5 seulement)

🔗 [Accéder au site](https://dellioss.github.io/site12/)

---

> « Nous mourons dans l’ombre pour que vous puissiez vivre dans la lumière. »  
> — Oméga-1, Directeur du Site-12
