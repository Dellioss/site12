
// Script simple (à étoffer)
console.log("Site-12 chargé.");
